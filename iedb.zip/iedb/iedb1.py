import subprocess,os,pandas as pd,time,glob,sys,shutil,re
from Bio.Seq import Seq
from Bio.Alphabet import IUPAC, _verify_alphabet
from Bio import SeqIO



if __name__=="__main__":
 try:
  start=time.time()
  cudir=os.getcwd()
  infl=raw_input("Enter the file name")
  type(infl)
  
  if "/" in infl:
     
     filename=infl.split("/")[-1]
     name=filename.split(".")[0]
  else:
    
    filename=infl
    name=infl.split(".")[0] 
  inpath = os.path.join(cudir+"/input_file")
  fpath=raw_input("Enter the predict_binding.py path :") #/sadika/soft/mhc_i/src"
  type(fpath)
  if os.path.exists(inpath) and os.path.isdir(inpath):
    shutil.rmtree(inpath)
  os.mkdir("input_file")
  
  dirpath = os.path.join(cudir+"/"+name)
  
  if os.path.exists(dirpath) and os.path.isdir(dirpath):
    shutil.rmtree(dirpath)

  #print name,filename
  os.mkdir(cudir+"/"+name)
  
  subprocess.call(["cp",infl,cudir+"/input_file/"]) 
  fasta_sequence = SeqIO.parse(open(cudir+"/input_file/"+filename),"fasta")
  for fasta in fasta_sequence:
           
        name1, sequence = fasta.id, str(fasta.seq)
        
        my_prot = Seq(sequence, IUPAC.protein)
        if _verify_alphabet(my_prot)==False:
          with open(cudir+"/iedb_false_sequence.fasta", "a") as handle:
                 count = SeqIO.write(fasta, handle, "fasta")
          continue 
        else:
         ##print(my_prot, _verify_alphabet(my_prot))
         with open(cudir+"/"+name+"/"+name+".fasta", "a") as handle:
                 count = SeqIO.write(fasta, handle, "fasta")
  fasta_sequence = SeqIO.parse(open(cudir+"/"+name+"/"+name+".fasta"),"fasta")
  subprocess.call(["cp","-R",cudir+"/"+name+"/"+name+".fasta",fpath])
  with open(cudir+"/allelenames.txt") as allenm:
             for line in allenm:
                line=line.strip()
                alle=line.split(",")[0]
                lenal=line.split(",")[1]
                
                if alle.startswith("HLA") and int(lenal)==9:
                   with open(cudir+"/"+name+"/"+name+"_iedb.txt","a") as file_out:
                       subprocess.call(["python","predict_binding.py","ann",alle,lenal,fpath+"/"+name+".fasta"],cwd=fpath,stdout=file_out)
  
  fasta_sequence = SeqIO.parse(open(cudir+"/"+name+"/"+name+".fasta"),"fasta")
  with open(cudir+"/"+name+"/"+name+"_iedb_final_result.txt","w") as inter_fl: 
   
     inter_fl.write("Sequence_id\tdescription\tpeptide\tic50_min\tallele\n")
     
     for i,fasta in enumerate(fasta_sequence):
     
        
        name1, sequence = fasta.id, str(fasta.seq)
        print i
        description=fasta.description
        df=pd.read_csv(cudir+"/"+name+"/"+name+"_iedb.txt",sep="\t")
        df=df.drop(columns=["start","end","length","rank"],axis=1)
        df.ic50=pd.to_numeric(df.ic50, errors='coerce')
        df.seq_num=pd.to_numeric(df.seq_num, errors='coerce')
        df=df[df.ic50<=50]
        rows,cols=df.shape
        df=df.groupby("seq_num").agg({"peptide":lambda x :",".join(set(x)), \
                                 "ic50":lambda x :"".join(str(min(x))), \
                                  "allele":lambda x :",".join((set(x)))
                                 }).reset_index() 
        if i <rows:
            peptide=df.peptide.iloc[i]
            allele=df.allele.iloc[i]
            ic50=df.ic50.iloc[i]
            
            inter_fl.write(name1+"\t"+description+"\t"+str(peptide)+"\t"+str(ic50)+"\t"+str(allele)+"\n")
            
  
 except IOError as error:
    print "I/O error({0}): ".format(error)      
 print time.time()-start
